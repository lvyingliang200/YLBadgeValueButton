//
//  AppDelegate.h
//  YLBadgeValueButtonDemo
//
//  Created by 吕英良 on 2017/5/27.
//  Copyright © 2017年 吕英良. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

