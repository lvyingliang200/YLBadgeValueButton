//
//  ViewController.m
//  YLBadgeValueButtonDemo
//
//  Created by 吕英良 on 2017/5/27.
//  Copyright © 2017年 吕英良. All rights reserved.
//

#import "ViewController.h"
#import "YLBadgeValueButton.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self createButton];
    
}

- (void)createButton
{
    YLBadgeValueButton * button1 = [[YLBadgeValueButton alloc] initWithFrame:CGRectMake(100 , 100, 25, 25)];
    button1.value = @"11";
    [self.view addSubview:button1];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
